AHuffman VERSION 1.0


PROGRAM DESCRIPTION:
	This application is used for educational purposes. The program
	shows users how the Adaptive Huffman coding data compression 
	algorithm works. It uses a string as input and displays the 
	process of both encoding and decoding.

	We use the 26 lower-case letters of the English alphabet and the 
	whitespace as the input characters.

LANGUAGE USED:
	The language used is JAVA (JDK 1.2)

REQUIREMENTS TO RUN THE PROGRAM:
	Computer:	Any type of computer which can run the java 
                        virtual machine
	Software:	JDK1.2 
		    	MS-DOS to type the command lines

HOW TO RUN (START) THE PROGRAM:
			* Go to the DOS prompt 
			* Go to the directory where the class files are 
			  stored. From that directory and run the program using jdk1.2.
	
        	Example:  
			Go to the directory
			c:\>cd AHuffman
			c:\AHuffman>java AHuffman
			
			The application will appear on the screen.

REFERENCES:
            1) "Tools for Visualizing Text Compression Algorithms" 
               by Sami Khuri and Hsiu-Chin Hsu.
               Proceedings of the ACM Symposium on Applied Computing
               March 2000, Como, Italy.


            2) "Introduction to Data Compression" by K. Sayood
            Morgan Kaufmann Publishers, 1996.

COMMENTS:   send to khuri@cs.sjsu.edu or joy@cs.sjsu.edu